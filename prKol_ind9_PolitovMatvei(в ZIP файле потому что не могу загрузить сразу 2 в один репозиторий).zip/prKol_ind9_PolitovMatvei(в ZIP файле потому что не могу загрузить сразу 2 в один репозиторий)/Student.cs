﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind9_PolitovMatvei
{
    internal class Student
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Patronymic { get; set; }
        public string Group { get; set; }
        public int Grade1 { get; set; }
        public int Grade2 { get; set; }
        public int Grade3 { get; set; }
        public bool IsSessionPassed()
        {
            return Grade1 >= 3 && Grade2 >= 3 && Grade3 >= 3;
        }
        public static void DistributeByGrades(List<Student> source, Queue<Student> success, Queue<Student> failure)
        {
            success.Clear();
            failure.Clear();

            foreach (Student student in source)
            {
                if (student.IsSessionPassed())
                    success.Enqueue(student);
                else
                    failure.Enqueue(student);
            }
        }
        public override string ToString()
        {
            return $"{LastName} {FirstName} {Patronymic} | Группа: {Group} | Оценки: {Grade1}, {Grade2}, {Grade3} | {(IsSessionPassed() ? "Успевает" : "Не успевает")}";
        }
    }
}
