﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prKol_ind9_PolitovMatvei
{
    public partial class Form1 : Form
    {
        private Queue<Student> successfulStudents = new Queue<Student>();
        private Queue<Student> unsuccessfulStudents = new Queue<Student>();
        private List<Student> allStudents = new List<Student>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                LoadStudentsFromFile(openFileDialog1.FileName);
            }
        }

        private void LoadStudentsFromFile(string fileName)
        {
            try
            {
                allStudents.Clear();
                listBox1.Items.Clear();
                string[] lines = File.ReadAllLines(fileName);

                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) { continue; }

                    string[] parts = line.Split('|');
                    if (parts.Length == 7)
                    {
                        allStudents.Add(new Student
                        {
                            LastName = parts[0],
                            FirstName = parts[1],
                            Patronymic = parts[2],
                            Group = parts[3],
                            Grade1 = int.Parse(parts[4]),
                            Grade2 = int.Parse(parts[5]),
                            Grade3 = int.Parse(parts[6])
                        });
                    }
                }
                listBox1.Items.AddRange(allStudents.ConvertAll(s => s.ToString()).ToArray());
                label1.Text = $"Загружено: {allStudents.Count}";
                button2.Enabled = allStudents.Count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Student.DistributeByGrades(allStudents, successfulStudents, unsuccessfulStudents);
            listBox1.Items.Clear();
            listBox1.Items.Add("Успевающие студенты");
            foreach (var s in successfulStudents) { listBox1.Items.Add(s.ToString()); }

            listBox1.Items.Add("");
            listBox1.Items.Add("Неуспевающие студенты");
            foreach (var s in unsuccessfulStudents) { listBox1.Items.Add(s.ToString()); }

            label1.Text = $"Успешных: {successfulStudents.Count}, Остальных: {unsuccessfulStudents.Count}";
            button3.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SaveResultToFile(saveFileDialog1.FileName);
            }
        }

        private void SaveResultToFile(string fileName)
        {
            try
            {
                List<string> lines = new List<string> { "Успевающие студенты" };
                foreach (var s in successfulStudents) { lines.Add(s.ToString()); }

                lines.Add("");
                lines.Add("Неуспевающие студенты");
                foreach (var s in unsuccessfulStudents) { lines.Add(s.ToString()); }

                File.WriteAllLines(fileName, lines);
                MessageBox.Show("Результат сохранён!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }
    }
}
